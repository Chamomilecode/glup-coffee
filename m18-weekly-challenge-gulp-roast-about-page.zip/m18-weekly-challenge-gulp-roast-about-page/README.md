# M18 Weekly Challenge: Gulp Roast About Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/2u-uxuxi-bootcamp/pen/zYPXLGw](https://codepen.io/2u-uxuxi-bootcamp/pen/zYPXLGw).

